import React from 'react'
import { createRoot } from 'react-dom/client'
import AiToolsDashboard from './AiToolsDashboard'
import './styles.css'

createRoot(document.getElementById('root')).render(<AiToolsDashboard />)
