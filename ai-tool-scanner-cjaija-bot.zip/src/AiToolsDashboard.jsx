import React, { useEffect, useState } from "react";

export default function AiToolsDashboard() {
  const [items, setItems] = useState([]);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All");
  const [sourceFilter, setSourceFilter] = useState("All");
  const [sortBy, setSortBy] = useState("trending");
  const [onlyNew, setOnlyNew] = useState(false);
  const [categories, setCategories] = useState([]);
  const [sources, setSources] = useState([]);

  useEffect(() => {
    async function load() {
      try {
        const resp = await fetch("/tools_db.json", { cache: "no-store" });
        if (!resp.ok) throw new Error("Could not load tools_db.json");
        const data = await resp.json();
        const normalized = (data || []).map((it) => ({
          ...it,
          first_seen_iso: it.first_seen_iso || it.published || new Date().toISOString(),
          categories: (it.categories || "").split(";").map((s) => s.trim()).filter(Boolean),
        }));
        setItems(normalized);
        const catSet = new Set();
        const srcSet = new Set();
        normalized.forEach((it) => {
          it.categories.forEach((c) => catSet.add(c));
          if (it.source) srcSet.add(it.source);
        });
        setCategories(["All", ...Array.from(catSet).sort()]);
        setSources(["All", ...Array.from(srcSet).sort()]);
      } catch (e) {
        console.error(e);
      }
    }
    load();
  }, []);

  const scoreFor = (it) => {
    const ageHours = (Date.now() - new Date(it.first_seen_iso).getTime()) / (1000 * 60 * 60);
    const recencyScore = Math.max(0, 1 - Math.min(ageHours / (24 * 14), 1));
    const boost = it.categories.includes("Generative AI") ? 0.2 : 0;
    return recencyScore + boost;
  };

  const filtered = items
    .filter((it) => {
      if (category !== "All" && !(it.categories || []).includes(category)) return false;
      if (sourceFilter !== "All" && it.source !== sourceFilter) return false;
      if (query) {
        const q = query.toLowerCase();
        const text = `${it.title} ${it.description} ${it.link}`.toLowerCase();
        if (!text.includes(q)) return false;
      }
      if (onlyNew) {
        const ageDays = (Date.now() - new Date(it.first_seen_iso).getTime()) / (1000 * 60 * 60 * 24);
        if (ageDays > 7) return false;
      }
      return true;
    })
    .sort((a, b) => {
      if (sortBy === "trending") return scoreFor(b) - scoreFor(a);
      if (sortBy === "newest") return new Date(b.first_seen_iso) - new Date(a.first_seen_iso);
      return a.title.localeCompare(b.title);
    });

  const groupedByCategory = filtered.reduce((acc, it) => {
    const key = (it.categories && it.categories[0]) || "Other";
    if (!acc[key]) acc[key] = [];
    acc[key].push(it);
    return acc;
  }, {});

  return (
    <div className="max-w-6xl mx-auto p-4">
      <header className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-extrabold">ai-tool-scanner — Daily Trend Dashboard</h1>
          <p className="text-sm text-muted-foreground mt-1">Auto-updates from your scanner. No API required — reads tools_db.json.</p>
        </div>
        <div className="text-sm text-right">
          <div>Items indexed: <strong>{items.length}</strong></div>
          <div>Showing: <strong>{filtered.length}</strong></div>
        </div>
      </header>

      <section className="bg-white rounded-2xl shadow p-4 mb-6 grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="col-span-2">
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search title, description, link..."
            className="w-full p-3 rounded-lg border"
          />
        </div>

        <div className="space-y-2">
          <select value={category} onChange={(e) => setCategory(e.target.value)} className="w-full p-2 rounded-lg border">
            {categories.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>

          <select value={sourceFilter} onChange={(e) => setSourceFilter(e.target.value)} className="w-full p-2 rounded-lg border">
            {sources.map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>

          <div className="flex gap-2">
            <select value={sortBy} onChange={(e) => setSortBy(e.target.value)} className="flex-1 p-2 rounded-lg border">
              <option value="trending">Trending</option>
              <option value="newest">Newest</option>
              <option value="alpha">A → Z</option>
            </select>
            <button onClick={() => setOnlyNew((v) => !v)} className={`p-2 rounded-lg border ${onlyNew ? "bg-blue-50" : ""}`}>
              {onlyNew ? "Only 7d" : "All time"}
            </button>
          </div>
        </div>
      </section>

      <main className="space-y-6">
        <div>
          <h2 className="text-xl font-semibold mb-3">Top trending (summary)</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {filtered.slice(0, 6).map((it) => (
                <article key={it.id} className="p-4 rounded-lg border bg-white shadow-sm">
                <a href={it.link} target="_blank" rel="noreferrer" className="text-lg font-medium line-clamp-2">{it.title}</a>
                <div className="text-xs text-muted-foreground mt-2">{it.categories.join(", ") || "Other"} • {new Date(it.first_seen_iso).toLocaleString()}</div>
                <p className="mt-2 text-sm line-clamp-3">{it.description}</p>
              </article>
            ))}
          </div>
        </div>

        <div>
          <h2 className="text-xl font-semibold mb-3">By function / category</h2>
          <div className="space-y-6">
            {Object.keys(groupedByCategory).length === 0 && <div className="text-sm text-muted-foreground">No items match your filters.</div>}
            {Object.entries(groupedByCategory).map(([cat, list]) => (
              <section key={cat} className="bg-white rounded-xl shadow p-4">
                <h3 className="font-semibold mb-3">{cat} <span className="text-sm text-muted-foreground">({list.length})</span></h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {list.map((it) => (
                    <div key={it.id} className="p-3 border rounded-lg">
                      <a href={it.link} target="_blank" rel="noreferrer" className="font-medium">{it.title}</a>
                      <div className="text-xs text-muted-foreground mt-1">{it.source} • {new Date(it.first_seen_iso).toLocaleString()}</div>
                      <p className="text-sm mt-2 line-clamp-4">{it.description}</p>
                    </div>
                  ))}
                </div>
              </section>
            ))}
          </div>
        </div>
      </main>

      <footer className="mt-8 text-center text-sm text-muted-foreground">
        Built for: daily tool discovery — reads tools_db.json (update via GitHub Actions). • No external API required.
      </footer>
    </div>
  );
}
